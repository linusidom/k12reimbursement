from django.contrib import admin
from converter.models import ReimburseModel, MileageModel
# Register your models here.
admin.site.register(ReimburseModel)
admin.site.register(MileageModel)